Work by Alex Shane and Dylan Whitney.

MS1 work:
    Alex: functions uint256_create and uint256_create_from_u32, wrote all tests
    Dylan: wrote the git_bits function.

MS2 work:
    Alex: functions for rotating and hex functions, created tests for rotate and hex functions 
    Dylan: wrote add, subtract, negate, created tests for those functions with ruby script