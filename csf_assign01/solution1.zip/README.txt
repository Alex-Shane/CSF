Work by Alex Shane and Dylan Whitney.

Alex work: wrote the functions uint256_create and uint256_create_from_u32
Dylan work: wrote the git_bits function.

No tests added for Milestone 1. Will add tests for Milestone 2.