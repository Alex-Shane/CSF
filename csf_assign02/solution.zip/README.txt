MS1:
    Alex work: hash function, find_insert, free_chain, isspace, isalpha, main, compare (assembly)
    Dylan work: read_next, dict_find_insert, wc_str_compare, isspace (assembly), isalpha (assembly)
