MS1:
    Alex work: hash function, find_insert, free_chain, isspace, isalpha, main, compare (assembly)
    Dylan work: read_next, dict_find_insert, wc_str_compare, isspace (assembly), isalpha (assembly)
MS2:
    Alex work: both finds, isspace, read_next, compare, main 
    Dylan work: free_chain, hash, is_alpha, to_lower, copy 