MS1 work:
    Alex: main
    Dylan: Makefile