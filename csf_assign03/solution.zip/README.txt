MS1 work:
    Alex: main, csfimfuncs 
    Dylan: Makefile

MS2 work:
    Alex: cache misses logic (stores and loads), created 3 structs outline, logic in main 
    Dylan: cache hits logic (stores and loads), logic for timestamps and cache counter