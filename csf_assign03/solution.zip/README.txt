MS1 work:
    Alex: main, csfimfuncs 
    Dylan: Makefile